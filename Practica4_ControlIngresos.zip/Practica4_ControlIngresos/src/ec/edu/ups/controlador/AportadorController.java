package ec.edu.ups.controlador;

import ec.edu.ups.modelo.Aportador;
import ec.edu.ups.modelo.ProcesadorArchivo;
import ec.edu.ups.vista.ConsolaView;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class AportadorController {
    private ConsolaView vista;
    private ProcesadorArchivo procesador;
    private List<Aportador> registros;

    public AportadorController() {
        this.vista = new ConsolaView();
        this.procesador = new ProcesadorArchivo();
    }

    public void iniciar() {
        int opcion = 0;
        do {
            opcion = vista.menu();
            switch (opcion) {
                case 1:
                    cargar();
                    break;
                case 2:
                    vista.mostrarRegistros(registros);
                    break;
                case 3:
                    vista.mostrarResumen(registros);
                    break;
                case 4:
                    vista.mensaje("¡Hasta luego!");
                    break;
                default:
                    vista.mensaje("[Error] Opción inválida. Intente de nuevo.");
            }
        } while (opcion != 4);
    }

    private void cargar() {
        Path ruta = Paths.get("registro_ingresos.txt");
        if (!Files.exists(ruta)) {
            try {
                String contenidoPrueba = "Aportador Juan Perez, Cédula: 0102030405, Correo: juan@gmail.com, Monto: $150.00\n" +
                                         "Aportador Maria Gomez, Cédula: 12345, Correo: maria@@gmail.com, Monto: 0 dólares\n" +
                                         "Aportador Carlos Ruiz, Cédula: 0987654321, Correo: carlos@hotmail.com, Monto: 75.50 USD\n";
                Files.writeString(ruta, contenidoPrueba);
            } catch (Exception e) {
                // ignorar
            }
        }
        this.registros = procesador.procesar(ruta);
        if (this.registros != null && !this.registros.isEmpty()) {
            vista.mensaje("Archivo procesado exitosamente. Se detectaron " + registros.size() + " registros.");
        } else {
            vista.mensaje("[Aviso] No se pudieron extraer registros del archivo.");
        }
    }
}
