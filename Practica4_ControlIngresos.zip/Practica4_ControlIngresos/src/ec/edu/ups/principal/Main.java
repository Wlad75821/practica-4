package ec.edu.ups.principal;

import ec.edu.ups.controlador.AportadorController;

public class Main {
    public static void main(String[] args) {
        AportadorController controlador = new AportadorController();
        controlador.iniciar();
    }
}
