package ec.edu.ups.vista;

import ec.edu.ups.modelo.Aportador;
import java.util.List;
import java.util.Scanner;

public class ConsolaView {
    private Scanner scanner;

    public ConsolaView() {
        this.scanner = new Scanner(System.in);
    }

    public int menu() {
        System.out.println("\n========================================");
        System.out.println("          CONTROL DE INGRESOS           ");
        System.out.println("========================================");
        System.out.println("1. Leer y procesar archivo");
        System.out.println("2. Mostrar registros y validaciones");
        System.out.println("3. Mostrar resumen");
        System.out.println("4. Salir");
        System.out.print("Seleccione una opción: ");
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public void mostrarRegistros(List<Aportador> registros) {
        if (registros == null || registros.isEmpty()) {
            System.out.println("\n[Aviso] No hay registros cargados. Procese el archivo primero.");
            return;
        }
        System.out.println("\n----------------------------------------");
        System.out.println(" LISTADO DE REGISTROS Y VALIDACIONES");
        System.out.println("----------------------------------------");
        int i = 1;
        for (Aportador a : registros) {
            String estadoCedula = a.isCedulaValida() ? "VÁLIDO" : "ERROR";
            String estadoCorreo = a.isCorreoValido() ? "VÁLIDO" : "ERROR";
            String estadoMonto = a.isMontoValido() ? "VÁLIDO" : "ERROR";
            System.out.printf("[%d] Cédula: %s (%s) | Correo: %s (%s) | Monto: %s (%s)\n",
                    i++, a.getCedula(), estadoCedula, a.getCorreo(), estadoCorreo, a.getMontoTexto(), estadoMonto);
        }
    }

    public void mostrarResumen(List<Aportador> registros) {
        if (registros == null || registros.isEmpty()) {
            System.out.println("\n[Aviso] No hay registros cargados. Procese el archivo primero.");
            return;
        }
        int totalRegistros = registros.size();
        int validos = 0;
        double sumaTotal = 0;
        int erroresCedula = 0;
        int erroresCorreo = 0;
        int erroresMonto = 0;

        for (Aportador a : registros) {
            if (a.isRegistroValido()) {
                validos++;
                sumaTotal += a.getMonto();
            }
            if (!a.isCedulaValida()) erroresCedula++;
            if (!a.isCorreoValido()) erroresCorreo++;
            if (!a.isMontoValido()) erroresMonto++;
        }

        System.out.println("\n========================================");
        System.out.println("                RESUMEN                 ");
        System.out.println("========================================");
        System.out.println("Registros detectados: " + totalRegistros);
        System.out.println("Registros completamente válidos: " + validos);
        System.out.printf("Total de ingresos válidos: $%,.2f\n", sumaTotal);
        System.out.println("Errores por campo:");
        System.out.println(" - Cédulas incorrectas: " + erroresCedula);
        System.out.println(" - Correos incorrectos: " + erroresCorreo);
        System.out.println(" - Montos incorrectos: " + erroresMonto);
        System.out.println("========================================");
    }

    public void mensaje(String msg) {
        System.out.println("\n" + msg);
    }
}
