package ec.edu.ups.modelo;

public class Aportador {
    private String cedula;
    private String correo;
    private String montoTexto;
    private double monto;
    private boolean cedulaValida;
    private boolean correoValido;
    private boolean montoValido;

    public Aportador(String cedula, String correo, String montoTexto) {
        this.cedula = cedula != null ? cedula.trim() : "";
        this.correo = correo != null ? correo.trim() : "";
        this.montoTexto = montoTexto != null ? montoTexto.trim() : "";
        validar();
    }

    private void validar() {
        if (this.cedula != null && this.cedula.matches("\\d{10}")) {
            this.cedulaValida = true;
        } else {
            this.cedulaValida = false;
        }

        if (this.correo != null && this.correo.matches("^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$")) {
            this.correoValido = true;
        } else {
            this.correoValido = false;
        }

        try {
            String limpio = this.montoTexto.replaceAll("[^\\d.,]", "").replace(",", ".");
            if (!limpio.isEmpty()) {
                this.monto = Double.parseDouble(limpio);
                this.montoValido = (this.monto > 0);
            } else {
                this.montoValido = false;
            }
        } catch (NumberFormatException e) {
            this.montoValido = false;
        }
    }

    public boolean isRegistroValido() {
        return cedulaValida && correoValido && montoValido;
    }

    public String getCedula() { return cedula; }
    public String getCorreo() { return correo; }
    public String getMontoTexto() { return montoTexto; }
    public double getMonto() { return monto; }
    public boolean isCedulaValida() { return cedulaValida; }
    public boolean isCorreoValido() { return correoValido; }
    public boolean isMontoValido() { return montoValido; }
}
