package ec.edu.ups.modelo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProcesadorArchivo {
    private static final Pattern PATTERN_CEDULA = Pattern.compile("(?<!\\d)\\d{6,12}(?!\\d)");
    private static final Pattern PATTERN_CORREO = Pattern.compile("[\\w._%+-]*@[\\w.-]*\\.[a-zA-Z]{2,6}|[\\w._%+-]+@@[\\w.-]+");
    private static final Pattern PATTERN_MONTO = Pattern.compile("(?:\\$\\s*\\d+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?\\s*(?:\\$|USD|dólares))", Pattern.CASE_INSENSITIVE);

    public List<Aportador> procesar(Path ruta) {
        List<Aportador> lista = new ArrayList<>();
        try {
            String contenido = Files.readString(ruta);

            Matcher matcherCedula = PATTERN_CEDULA.matcher(contenido);
            Matcher matcherCorreo = PATTERN_CORREO.matcher(contenido);
            Matcher matcherMonto = PATTERN_MONTO.matcher(contenido);

            while (matcherCedula.find() && matcherCorreo.find() && matcherMonto.find()) {
                String cedula = matcherCedula.group();
                String correo = matcherCorreo.group();
                String monto = matcherMonto.group();

                Aportador aportador = new Aportador(cedula, correo, monto);
                lista.add(aportador);
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
        return lista;
    }
}
